@echo off
setlocal
cd /d "%~dp0"
if not exist backend\.venv\Scripts\activate.bat (
  echo First run: installing everything, please wait...
  call 1_SETUP_FIRST_TIME.bat
  if errorlevel 1 exit /b 1
)
call 2_RUN.bat
