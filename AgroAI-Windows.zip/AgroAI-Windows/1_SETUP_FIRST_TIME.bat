@echo off
setlocal
cd /d "%~dp0"
echo === AGRO AI first-time setup (needs internet, takes a few minutes) ===
where python >nul 2>&1 || (echo Python 3.12+ not found. Install from python.org and tick "Add python.exe to PATH". & pause & exit /b 1)
where node >nul 2>&1 || (echo Node.js 20+ not found. Install from nodejs.org. & pause & exit /b 1)
cd backend
if not exist .venv python -m venv .venv || goto :fail
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip || goto :fail
pip install -r requirements.txt || goto :fail
alembic upgrade head || goto :fail
cd ..\frontend
call npm install || goto :fail
echo.
echo Setup finished. Now double-click 2_RUN.bat
pause
exit /b 0
:fail
echo.
echo Setup failed - see the message above.
pause
exit /b 1
