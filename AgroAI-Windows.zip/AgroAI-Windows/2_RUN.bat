@echo off
cd /d "%~dp0"
if not exist backend\.venv (echo Run 1_SETUP_FIRST_TIME.bat first. & pause & exit /b 1)
start "AGRO AI backend" cmd /k "cd /d %~dp0backend && call .venv\Scripts\activate.bat && uvicorn app.main:app --port 8000"
start "AGRO AI frontend" cmd /k "cd /d %~dp0frontend && npm run dev"
timeout /t 8 >nul
start http://localhost:5173
