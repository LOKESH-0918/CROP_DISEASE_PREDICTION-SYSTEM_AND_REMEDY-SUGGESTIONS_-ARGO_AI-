AGRO AI - run on Windows
1. Install Python 3.12+ (tick "Add to PATH") and Node.js 20+.
2. Double-click 1_SETUP_FIRST_TIME.bat (once, needs internet).
3. (Or just double-click START_AGRO_AI.bat: it does steps 2 and 3.) Double-click 2_RUN.bat. The app opens at http://localhost:5173
Close the two black windows to stop.

Notes: backend\.env is preconfigured for localhost and uses your Neon database
(local runs touch real data; to isolate, set DATABASE_URL=sqlite:///./agroai.db in backend\.env).
Google sign-in needs http://localhost:5173 and http://localhost:8000/api/v1/auth/google/callback added in Google Cloud.
backend\.env contains live secrets: do not share publicly.
